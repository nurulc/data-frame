export * from './arrayutils';
export * from './intset';
export * from './prod';
export * from './flatten';
import _ap from './prod';
import _r from './reord';
export const reord = _r, 
 			 arrProd=_ap;