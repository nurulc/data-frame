export default class BaseFrame {
	
}